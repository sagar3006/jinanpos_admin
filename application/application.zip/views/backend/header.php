<div class="row">
	<!-- SOFTWARE TITLE -->
    <div class="col-md-12 col-sm-12 clearfix" style="text-align:center;">
        <h2 style="font-weight:200; margin:0px;"><?php echo $system_name; ?></h2>
    </div>
	<!-- Profile Info and Notifications -->
	<div class="col-md-6 col-sm-8 clearfix">

	</div>


	<!-- Raw Links -->
	<div class="col-md-6 col-sm-4 clearfix hidden-xs">

		<ul class="list-inline links-list pull-right">

			<li>
				<a href="<?php echo base_url(); ?>index.php?login/logout">
					Log Out <i class="entypo-logout right"></i>
				</a>
			</li>
		</ul>

	</div>

</div>

<hr />