<!-- Footer -->
<footer class="main">
	
	&copy; 2018 <strong><?php echo $system_name; ?></strong> by <a href="http://jinanitltd.com" target="_blank">JinanIT</a>

</footer>